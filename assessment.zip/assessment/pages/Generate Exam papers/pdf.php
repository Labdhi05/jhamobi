<?php
if(!empty($_POST['s']))
{
    $name1=$_POST['fn'];
    $name2=$_POST['ln'];
    $mail=$_POST['e'];
    $pas1=$_POST['p'];
    $pas2=$_POST['pa'];
    $mark1=$_POST['tm'];
    $mark2=$_POST['m'];

    require("fpdf186/fpdf.php");
    $pdf = new FPDF();
    $pdf -> AddPage();

    $pdf -> SetFont("Arial","",16);
    $pdf -> Cell(0,10,"$name1",1,1,'C');
    $pdf->Ln();

    $pdf->SetFont('Arial','',11);
    $pdf->Cell(40,10,"Date of Examination - $name2",'C');
    $pdf->Ln();

    $pdf->SetFont('Arial','',11);
    $pdf->Cell(40,10,"Exam Duration - $mail Hrs",'C');
    $pdf->Ln();

    $pdf->SetFont('Arial','',11);
    $pdf->Cell(40,10," Program Name - $pas1",'C');
    $pdf->Ln();

    $pdf->SetFont('Arial','',11);
    $pdf->Cell(40,10," Course Name - $pas2",'C');
    $pdf->Ln();

    $pdf->SetFont('Arial','',11);
    $pdf->Cell(40,10," Total Marks - $mark1",'C');
    $pdf->Ln();

    $pdf->SetFont('Arial','',11);
    $pdf->Cell(40,10,"Each Question contain - $mark2",'C');
    $pdf->Ln();

    $pdf -> SetFont("Arial","",16);
    $pdf -> Cell(0,10,"Read the question carefully . \n All THE BEST ! ",1,1,'C');
    $pdf->Ln();

    $conn=mysqli_connect('localhost','root','','jhamobi_assessment');
    $result=mysqli_query($conn,"select * from question");
    $result2=mysqli_query($conn,"SELECT * FROM `answer_options`");


    while($row=mysqli_fetch_array($result))
                  {
                    

                    $QuestionText=$row['questionText'];


                    while($col=mysqli_fetch_array($result2))
                    {
                    $question1Text=$col['answerOpt1Text'];
                    $question2Text=$col['answerOpt2Text'];
                    $question3Text=$col['answerOpt3Text'];
                    $question4Text=$col['answerOpt4Text'];
                    $pdf->Ln();
                    
                    $pdf -> Cell(40,5," $QuestionText ",'L');


                    $pdf->Ln();
                    $pdf->Ln();
                    
                    $pdf -> Cell(40,5,"1. $question1Text ",'C');
                    $pdf->Ln();
                    $pdf -> Cell(40,5,"2. $question2Text ",'C');
                    $pdf->Ln();
                    $pdf -> Cell(40,5,"3. $question3Text ",'C');
                    $pdf->Ln();
                    $pdf -> Cell(40,5,"4. $question4Text ",'C');
                    
                    $pdf->Ln();
                    $pdf->Ln();
                    }
                   
		 
                  }

                  
                  

    

    
    
                  




    
    


    $pdf->output();

    

}
?>

