<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Exam | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
		<style>
		.example-modal .modal {
		  position: relative;
		  top: auto;
		  bottom: auto;
		  right: auto;
		  left: auto;
		  display: block;
		  z-index: 1;
		}

		.example-modal .modal {
		  background: transparent !important;
		}
	</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <!--<span class="logo-lg"><b>Admin</b>LTE</span>-->
      <span class="logo-lg"><b><?php echo $_SESSION['userType'];?></b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

	<h4 style="color:white; text-align:center;" class="col-sm-10 control-label">Assessment System for Education Institute <br>
  </h4>
		
		<div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
		<li class="dropdown user user-menu">
		<a href="../../logout.php" class="btn btn-danger"><i class='glyphicon glyphicon-log-out'></i>Sign out</a>
		</li>
        </ul>
      </div>

      </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <?php include ('menu.php');?>
  </aside>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Generate Exam paper
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"></a>Generate Exam paper</li>
        <li class="active">Create Questions paper </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
	  
		<div class="col-xs-12">
		<div class="box-header with-border">
              <h3 class="box-title">Add New Quesion</h3>
            </div>

            <div class="box-body">
            <form action="pdf.php" method="POST">
            <table align="center">
            <tr>
            <td>Institution Name <td><input type="text" name="fn"></td></tr>
            <tr>
            <td><br>Exam Date <td><input type="date" name="ln"></td></tr>
            <tr>
            <td><br>Exam Duration<td><input type="time" name="e"></td></tr>
            <tr>
            <td><br>program Name <td><input type="text" name="p"></td></tr>
            <tr>
            <td><br>Course Name<td><input type="text" name="pa"></td></tr>

            <tr>
            <td><br>Total marks - <td><input type="number" name="tm"></td></tr>
            <tr>
            <td><br> Each question Marks - <td><input type="number" name="m"></td></tr>


            <tr>
            <td><br><input type="submit" name="s" ></td></tr>

                  <?php
                  $result=mysqli_query($conn,"select * from question");

                  while($row=mysqli_fetch_array($result))
                  {
                    $questionText=$row['questionText'];

                    echo 
                    "<td>$questionText</td>";
		 
                  }
                    
                  ?>

            
            </form>
            </table>

            </div>
                
    </div>
    

                 
			
          
          

          
            
            
				


  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <!--<b>Version</b> 2.4.13-->
      <!-- <b>Version</b> 1.0.0 -->
    </div>
	<strong>Copyright &copy; Jhamobi Technologies Pvt. Ltd. 2022-2023</strong> All rights reserved.
	
	
  </footer>
  